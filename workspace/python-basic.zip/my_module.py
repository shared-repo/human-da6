title = "테스트를 위한 모듈"

def show_msg(msg):
    print(msg)

def multiply(a, b):
    return a * b