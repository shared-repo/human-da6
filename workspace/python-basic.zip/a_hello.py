
print("hello, python programming world !!!")

print("this is my first python program !!!")

print("bye")