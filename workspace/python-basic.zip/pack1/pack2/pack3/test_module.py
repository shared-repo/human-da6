
def get_greetings(name):
    return f"반갑습니다. {name}님. 유쾌한 주말 보내세요"